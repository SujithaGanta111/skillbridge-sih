import { useState } from 'react';
import { Badge, Progress } from '../components/UI.jsx';
import { JOBS } from '../data/mockData.js';

export default function Internships({ onApply, applied }) {
  const [filter, setFilter] = useState('All');
  const list = JOBS.filter((j) => filter === 'All' || j.type === filter);

  return (
    <div className="content">
      <div className="h1">Internships & Jobs</div>
      <p className="sub">Opportunities ranked by skill-match percentage with your profile.</p>

      <div style={{ margin: '14px 0' }}>
        {['All', 'Internship', 'Full-time'].map((f) => (
          <button
            key={f}
            className={'btn sm ' + (filter === f ? '' : 'outline')}
            style={{ marginRight: 8 }}
            onClick={() => setFilter(f)}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid grid-2">
        {list.map((j) => (
          <div className="card" key={j.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
              <div>
                <b>{j.title}</b>
                <div className="sub">{j.co} · {j.loc} · {j.type}</div>
              </div>
              <Badge type={j.match > 75 ? 'ok' : j.match > 55 ? 'warn' : 'bad'}>{j.match}% match</Badge>
            </div>
            <div style={{ margin: '10px 0' }}><Progress v={j.match} /></div>
            <div>{j.skills.map((s) => <span className="tag" key={s}>{s}</span>)}</div>
            <div style={{ marginTop: 10 }}>
              {applied.includes(j.id) ? (
                <Badge type="ok">Applied ✓</Badge>
              ) : (
                <button className="btn sm" onClick={() => onApply(j)}>Apply Now</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
