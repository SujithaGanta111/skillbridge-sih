import { Card } from '../components/UI.jsx';
import { INSTITUTION_STATS } from '../data/mockData.js';

export default function InstitutionDashboard() {
  return (
    <div className="content">
      <div className="h1">Institution Admin Dashboard</div>
      <div className="grid grid-3" style={{ marginTop: 16 }}>
        <Card title="Placement Rate">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--ok)' }}>{INSTITUTION_STATS.placementRate}%</div>
        </Card>
        <Card title="Avg. Package">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--brand)' }}>{INSTITUTION_STATS.avgPackage}</div>
        </Card>
        <Card title="Active Industry MOUs">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--accent)' }}>{INSTITUTION_STATS.activeMOUs}</div>
        </Card>
      </div>
      <Card title="Industry Partners" style={{ marginTop: 16 }}>
        <div>{INSTITUTION_STATS.partners.map((s) => <span className="tag" key={s}>{s}</span>)}</div>
      </Card>
    </div>
  );
}
