import { Card, Badge } from '../components/UI.jsx';
import { INDUSTRY_STATS, JOBS } from '../data/mockData.js';

export default function IndustryDashboard() {
  return (
    <div className="content">
      <div className="h1">Industry Partner Dashboard</div>
      <div className="grid grid-3" style={{ marginTop: 16 }}>
        <Card title="Open Roles Posted">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--brand)' }}>{INDUSTRY_STATS.openRoles}</div>
        </Card>
        <Card title="Total Applicants">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--accent)' }}>{INDUSTRY_STATS.applicants}</div>
        </Card>
        <Card title="Avg. Skill Match">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--ok)' }}>{INDUSTRY_STATS.avgMatch}%</div>
        </Card>
      </div>

      <Card title="Top In-Demand Skills" style={{ marginTop: 16 }}>
        <div>{INDUSTRY_STATS.topSkillDemand.map((s) => <span className="tag" key={s}>{s}</span>)}</div>
      </Card>

      <Card title="Top Matched Candidates" style={{ marginTop: 16 }}>
        <table className="table">
          <thead><tr><th>Candidate</th><th>Role Applied</th><th>Match</th></tr></thead>
          <tbody>
            {JOBS.map((j) => (
              <tr key={j.id}>
                <td>Student #{j.id}0{j.id}</td>
                <td>{j.title}</td>
                <td><Badge type={j.match > 75 ? 'ok' : 'warn'}>{j.match}%</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
