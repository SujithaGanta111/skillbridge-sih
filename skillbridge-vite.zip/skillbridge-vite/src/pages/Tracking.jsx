const STAGES = ['Applied', 'Shortlisted', 'Interview', 'Selected'];

export default function Tracking({ applications }) {
  return (
    <div className="content">
      <div className="h1">Application Tracking</div>
      <p className="sub">Live pipeline status of your applications.</p>

      <div className="pipeline" style={{ marginTop: 16 }}>
        {STAGES.map((st) => (
          <div className="stage" key={st}>
            <h4>{st}</h4>
            {applications.filter((a) => a.stage === st).map((a) => (
              <div className="appcard" key={a.id}>
                <b>{a.title}</b>
                <div className="sub">{a.co}</div>
              </div>
            ))}
            {applications.filter((a) => a.stage === st).length === 0 && (
              <div className="sub" style={{ fontSize: 12 }}>No applications</div>
            )}
          </div>
        ))}
      </div>

      {applications.length === 0 && (
        <div className="card" style={{ marginTop: 16, textAlign: 'center' }}>
          <p className="sub">You haven't applied to anything yet. Head to Internships & Jobs to apply.</p>
        </div>
      )}
    </div>
  );
}
