import { useNavigate } from 'react-router-dom';
import { Card, Badge } from '../components/UI.jsx';
import { TECH_SKILLS, SOFT_SKILLS, GAPS, COURSES } from '../data/mockData.js';

export default function SkillGap() {
  const navigate = useNavigate();
  return (
    <div className="content">
      <div className="h1">Skill Gap Analysis</div>
      <p className="sub">Comparing your current skills against target industry role requirements.</p>

      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <Card title="💪 Your Strengths">
          {TECH_SKILLS.concat(SOFT_SKILLS).filter((s) => s.v >= 65).map((s) => (
            <div key={s.n} style={{ marginBottom: 8 }}>
              <Badge type="ok">{s.n} — {s.v}%</Badge>
            </div>
          ))}
        </Card>
        <Card title="⚠️ Missing / Weak Skills">
          {GAPS.map((g) => (
            <div key={g.skill} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <b>{g.skill}</b>
                <span className="sub">{g.have}% → target {g.need}%</span>
              </div>
              <div className="bar"><i style={{ width: g.have + '%', background: 'var(--warn)' }} /></div>
            </div>
          ))}
        </Card>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <div className="h2">Suggested Action Plan</div>
        <table className="table">
          <thead><tr><th>Gap</th><th>Recommended Course</th><th>Duration</th><th></th></tr></thead>
          <tbody>
            {COURSES.map((c) => (
              <tr key={c.t}>
                <td>{c.skill}</td>
                <td>{c.t}</td>
                <td>{c.dur}</td>
                <td><button className="btn sm outline" onClick={() => navigate('/jobs')}>View Roles</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
