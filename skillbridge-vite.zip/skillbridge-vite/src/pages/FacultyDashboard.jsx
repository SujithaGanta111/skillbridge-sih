import { Card } from '../components/UI.jsx';
import { FACULTY_STATS } from '../data/mockData.js';

export default function FacultyDashboard() {
  return (
    <div className="content">
      <div className="h1">Faculty / Mentor Dashboard</div>
      <div className="grid grid-3" style={{ marginTop: 16 }}>
        <Card title="Students Tracked">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--brand)' }}>{FACULTY_STATS.studentsTracked}</div>
        </Card>
        <Card title="Avg. Readiness Score">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--ok)' }}>{FACULTY_STATS.avgReadiness}%</div>
        </Card>
        <Card title="At-Risk Students">
          <div style={{ fontSize: 34, fontWeight: 800, color: 'var(--bad)' }}>{FACULTY_STATS.atRisk}</div>
        </Card>
      </div>
      <Card title="Most Common Skill Gaps (Cohort-wide)" style={{ marginTop: 16 }}>
        <div>{FACULTY_STATS.topGaps.map((s) => <span className="tag" key={s}>{s}</span>)}</div>
      </Card>
    </div>
  );
}
