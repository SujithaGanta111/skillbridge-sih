import { useNavigate } from 'react-router-dom';
import { Card } from '../components/UI.jsx';

const STEPS = ['Assess', 'Identify', 'Learn', 'Match', 'Apply', 'Get Placed'];

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="content">
      <div
        className="card"
        style={{
          textAlign: 'center',
          background: 'linear-gradient(135deg,var(--brand),var(--accent))',
          color: '#fff',
          border: 'none',
        }}
      >
        <h1 style={{ margin: '0 0 8px' }}>Welcome to SkillBridge</h1>
        <p style={{ opacity: 0.9, maxWidth: 640, margin: '0 auto' }}>
          Bridging the gap between academic skills and real industry requirements — for students,
          faculty, industry and institutions, on one platform.
        </p>
      </div>

      <div className="flowrow">
        {STEPS.map((s, i) => (
          <span key={s} style={{ display: 'contents' }}>
            <div className="flowstep">{i + 1}. {s}</div>
            {i < STEPS.length - 1 && <div className="flowarrow">→</div>}
          </span>
        ))}
      </div>

      <div className="grid grid-3">
        <Card title="🎯 For Students" sub="Know your gaps, close them, get hired">
          <p className="sub">
            Assess your skills, get a personalized gap analysis, targeted course recommendations
            and jobs matched to your real profile.
          </p>
          <button className="btn sm" onClick={() => navigate('/dashboard')}>Go to Dashboard</button>
        </Card>
        <Card title="🏢 For Industry" sub="Hire job-ready talent faster">
          <p className="sub">Post roles, see verified skill-matched candidates and reduce screening time.</p>
          <button className="btn sm outline" onClick={() => navigate('/industry')}>Industry View</button>
        </Card>
        <Card title="🏛️ For Institutions" sub="Track placement & curriculum ROI">
          <p className="sub">Monitor cohort readiness, skill gaps at scale, and placement outcomes.</p>
          <button className="btn sm outline" onClick={() => navigate('/institution')}>Institution View</button>
        </Card>
      </div>
    </div>
  );
}
