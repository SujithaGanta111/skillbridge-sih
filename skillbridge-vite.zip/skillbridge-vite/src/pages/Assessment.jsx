import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge } from '../components/UI.jsx';
import { ASSESSMENT_Q } from '../data/mockData.js';

export default function Assessment() {
  const [answers, setAnswers] = useState({});
  const [done, setDone] = useState(false);
  const navigate = useNavigate();

  const set = (i, v) => setAnswers({ ...answers, [i]: v });
  const submit = () => {
    setDone(true);
    setTimeout(() => navigate('/gap'), 900);
  };

  return (
    <div className="content">
      <div className="h1">Skill Assessment</div>
      <p className="sub">Answer honestly — this powers your Skill Gap Analysis and job matching.</p>
      <div className="card" style={{ marginTop: 16 }}>
        {ASSESSMENT_Q.map((item, i) => (
          <div className="qrow" key={i}>
            <label>{i + 1}. {item.q}</label>
            <input
              type="range"
              min="0"
              max="100"
              value={answers[i] ?? 50}
              onChange={(e) => set(i, e.target.value)}
            />
            <div className="sub">Self-rating: {answers[i] ?? 50}/100</div>
          </div>
        ))}
        {!done ? (
          <button className="btn" onClick={submit}>Submit Assessment</button>
        ) : (
          <div>
            <Badge type="ok">Assessment Submitted ✓</Badge>
            <p className="sub" style={{ marginTop: 8 }}>
              Your Skill Profile and Gap Analysis have been updated. Redirecting…
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
