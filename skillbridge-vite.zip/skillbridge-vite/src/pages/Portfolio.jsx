import { Card } from '../components/UI.jsx';
import { STUDENT, TECH_SKILLS, SOFT_SKILLS, CERTS, PROJECTS, ACHIEVEMENTS } from '../data/mockData.js';

export default function Portfolio() {
  return (
    <div className="content">
      <div className="h1">Digital Portfolio</div>
      <p className="sub">A shareable snapshot of {STUDENT.name}'s verified skills and work.</p>

      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <Card title="Skills">
          <div>
            {TECH_SKILLS.concat(SOFT_SKILLS).map((s) => (
              <span className="tag" key={s.n}>{s.n} · {s.v}%</span>
            ))}
          </div>
        </Card>
        <Card title="Certifications">
          {CERTS.map((c) => <div key={c} className="appcard">{c}</div>)}
        </Card>
        <Card title="Projects">
          {PROJECTS.map((p) => (
            <div key={p.t} className="appcard">
              <b>{p.t}</b>
              <div className="sub">{p.d}</div>
            </div>
          ))}
        </Card>
        <Card title="Achievements">
          {ACHIEVEMENTS.map((a) => <div key={a} className="appcard">🏆 {a}</div>)}
        </Card>
      </div>
    </div>
  );
}
