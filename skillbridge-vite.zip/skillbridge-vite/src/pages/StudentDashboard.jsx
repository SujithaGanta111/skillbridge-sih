import { useNavigate } from 'react-router-dom';
import { Card, Badge, Progress } from '../components/UI.jsx';
import { STUDENT, TECH_SKILLS, SOFT_SKILLS, GAPS, COURSES, JOBS, avg } from '../data/mockData.js';

export default function StudentDashboard({ applications }) {
  const navigate = useNavigate();
  const readiness = Math.round((avg(TECH_SKILLS, 'v') + avg(SOFT_SKILLS, 'v')) / 2);

  return (
    <div className="content">
      <div className="h1">Welcome back, {STUDENT.name.split(' ')[0]} 👋</div>
      <p className="sub">{STUDENT.branch} · {STUDENT.college}</p>

      <div className="grid grid-3" style={{ marginTop: 18 }}>
        <Card title="Skill Readiness Score">
          <div style={{ fontSize: 38, fontWeight: 800, color: 'var(--brand)' }}>{readiness}%</div>
          <Progress v={readiness} />
          <p className="sub" style={{ marginTop: 8 }}>Based on technical + soft skill assessment</p>
        </Card>
        <Card title="Skill Gaps to Close">
          <div style={{ fontSize: 38, fontWeight: 800, color: 'var(--warn)' }}>{GAPS.length}</div>
          <p className="sub">Priority gaps identified vs target roles</p>
          <button className="btn sm outline" onClick={() => navigate('/gap')}>View Gap Analysis</button>
        </Card>
        <Card title="Active Applications">
          <div style={{ fontSize: 38, fontWeight: 800, color: 'var(--accent)' }}>{applications.length}</div>
          <p className="sub">Track your pipeline status</p>
          <button className="btn sm outline" onClick={() => navigate('/track')}>Track Applications</button>
        </Card>
      </div>

      <div className="grid grid-2" style={{ marginTop: 18 }}>
        <Card title="Technical Skills">
          {TECH_SKILLS.map((s) => (
            <div key={s.n} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>{s.n}</span><b>{s.v}%</b>
              </div>
              <Progress v={s.v} />
            </div>
          ))}
        </Card>
        <Card title="Soft Skills">
          {SOFT_SKILLS.map((s) => (
            <div key={s.n} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>{s.n}</span><b>{s.v}%</b>
              </div>
              <Progress v={s.v} color="var(--accent)" />
            </div>
          ))}
        </Card>
      </div>

      <div className="grid grid-2" style={{ marginTop: 18 }}>
        <Card title="Recommended Courses" sub="Targeted at your biggest gaps">
          {COURSES.slice(0, 3).map((c) => (
            <div key={c.t} className="appcard">
              <b>{c.t}</b>
              <div className="sub">{c.p} · {c.dur}</div>
              <Badge type="warn">{c.skill}</Badge>
            </div>
          ))}
        </Card>
        <Card title="Recommended Internships / Jobs" sub="Matched to your current skill profile">
          {JOBS.slice(0, 3).map((j) => (
            <div key={j.id} className="appcard">
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <b>{j.title}</b>
                <Badge type={j.match > 75 ? 'ok' : j.match > 55 ? 'warn' : 'bad'}>{j.match}% match</Badge>
              </div>
              <div className="sub">{j.co} · {j.loc}</div>
            </div>
          ))}
          <button className="btn sm" onClick={() => navigate('/jobs')}>See All Opportunities</button>
        </Card>
      </div>
    </div>
  );
}
