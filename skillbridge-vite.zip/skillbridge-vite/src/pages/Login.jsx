import { useState } from 'react';

const ROLES = [
  ['student', '🎓', 'Student'],
  ['industry', '🏢', 'Industry Partner'],
  ['faculty', '🧑‍🏫', 'Faculty / Mentor'],
  ['institution', '🏛️', 'Institution Admin'],
];

export default function Login({ onLogin }) {
  const [role, setRole] = useState('student');
  return (
    <div className="loginwrap">
      <div className="loginbox">
        <div className="logo" style={{ color: 'var(--brand)', justifyContent: 'center' }}>
          <span style={{ background: 'var(--brand)', color: '#fff' }}>SB</span>SkillBridge
        </div>
        <p className="sub" style={{ textAlign: 'center', marginTop: 0 }}>
          SIH26044 — Academia-Industry Skill Mapping Portal
        </p>
        {ROLES.map((r) => (
          <div
            key={r[0]}
            className={'rolebtn' + (role === r[0] ? ' sel' : '')}
            onClick={() => setRole(r[0])}
          >
            <span style={{ fontSize: 20 }}>{r[1]}</span>
            <b>{r[2]}</b>
          </div>
        ))}
        <div style={{ marginTop: 14 }}>
          <label>Email</label>
          <input defaultValue={role + '@skillbridge.demo'} />
        </div>
        <div style={{ marginTop: 10, marginBottom: 16 }}>
          <label>Password</label>
          <input type="password" defaultValue="********" />
        </div>
        <button className="btn" style={{ width: '100%' }} onClick={() => onLogin(role)}>
          Login to SkillBridge
        </button>
        <p className="sub" style={{ textAlign: 'center', marginTop: 12, fontSize: 12 }}>
          Prototype login — no real authentication
        </p>
      </div>
    </div>
  );
}
