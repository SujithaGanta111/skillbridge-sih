export const STUDENT = { name: "Aarav Sharma", branch: "CSE, 3rd Year", college: "NIT Trichy" };

export const TECH_SKILLS = [
  { n: "JavaScript", v: 78 },
  { n: "Python", v: 65 },
  { n: "SQL", v: 55 },
  { n: "React", v: 60 },
  { n: "Data Structures", v: 70 },
  { n: "Cloud (AWS)", v: 30 },
];

export const SOFT_SKILLS = [
  { n: "Communication", v: 72 },
  { n: "Teamwork", v: 80 },
  { n: "Problem Solving", v: 68 },
  { n: "Leadership", v: 50 },
];

export const GAPS = [
  { skill: "Cloud (AWS)", have: 30, need: 70 },
  { skill: "System Design", have: 20, need: 65 },
  { skill: "SQL", have: 55, need: 75 },
  { skill: "Leadership", have: 50, need: 60 },
];

export const COURSES = [
  { t: "AWS Cloud Practitioner Essentials", p: "AWS Skill Builder", skill: "Cloud (AWS)", dur: "3 weeks" },
  { t: "System Design Primer", p: "Coursera", skill: "System Design", dur: "4 weeks" },
  { t: "Advanced SQL for Data Analysis", p: "Udemy", skill: "SQL", dur: "2 weeks" },
  { t: "Leadership in Tech Teams", p: "LinkedIn Learning", skill: "Leadership", dur: "1 week" },
];

export const JOBS = [
  { id: 1, title: "Frontend Developer Intern", co: "InfoNext Systems", match: 88, type: "Internship", loc: "Remote", skills: ["React", "JavaScript", "CSS"] },
  { id: 2, title: "Data Analyst Trainee", co: "Quantify Analytics", match: 74, type: "Full-time", loc: "Bengaluru", skills: ["SQL", "Python", "Excel"] },
  { id: 3, title: "Cloud Support Intern", co: "NimbusWorks", match: 52, type: "Internship", loc: "Hyderabad", skills: ["AWS", "Linux", "Networking"] },
  { id: 4, title: "Software Engineer - Backend", co: "CodeForge Pvt Ltd", match: 81, type: "Full-time", loc: "Pune", skills: ["Python", "SQL", "System Design"] },
  { id: 5, title: "UI/UX Design Intern", co: "PixelCraft Studio", match: 66, type: "Internship", loc: "Remote", skills: ["Figma", "CSS", "Communication"] },
];

export const CERTS = [
  "AWS Cloud Practitioner (In Progress)",
  "NPTEL - Data Structures & Algorithms",
  "HackerRank - JavaScript (Gold)",
];

export const PROJECTS = [
  { t: "Campus Event Manager", d: "Full-stack MERN app for college event registration." },
  { t: "Skill Gap Visualizer", d: "React dashboard analyzing student vs industry skill data." },
];

export const ACHIEVEMENTS = [
  "Winner - College Hackathon 2025",
  "Published article on Dev.to (1.2k views)",
  "Open source contributor - 3 PRs merged",
];

export const ASSESSMENT_Q = [
  { q: "Rate your proficiency in JavaScript", skill: "JavaScript" },
  { q: "Rate your proficiency in Python", skill: "Python" },
  { q: "Rate your proficiency in SQL / Databases", skill: "SQL" },
  { q: "Rate your proficiency in Cloud platforms (AWS/Azure/GCP)", skill: "Cloud (AWS)" },
  { q: "Rate your Communication skills", skill: "Communication" },
  { q: "Rate your Teamwork & Collaboration", skill: "Teamwork" },
];

export const INDUSTRY_STATS = { openRoles: 12, applicants: 340, avgMatch: 69, topSkillDemand: ["Python", "Cloud (AWS)", "React", "SQL"] };
export const FACULTY_STATS = { studentsTracked: 156, avgReadiness: 64, atRisk: 23, topGaps: ["Cloud", "System Design", "Leadership"] };
export const INSTITUTION_STATS = { placementRate: 78, avgPackage: "6.2 LPA", activeMOUs: 14, partners: ["InfoNext", "Quantify", "CodeForge", "NimbusWorks"] };

export function avg(arr, key) {
  return Math.round(arr.reduce((s, x) => s + x[key], 0) / arr.length);
}
