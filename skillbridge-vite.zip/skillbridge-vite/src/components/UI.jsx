export function Progress({ v, color }) {
  return (
    <div className="bar">
      <i style={{ width: v + '%', background: color || undefined }} />
    </div>
  );
}

export function Badge({ children, type }) {
  return <span className={'badge ' + (type || 'info')}>{children}</span>;
}

export function Card({ title, sub, children, style }) {
  return (
    <div className="card" style={style}>
      <div className="h2">{title}</div>
      {sub && <div className="sub" style={{ marginTop: -8, marginBottom: 12 }}>{sub}</div>}
      {children}
    </div>
  );
}
