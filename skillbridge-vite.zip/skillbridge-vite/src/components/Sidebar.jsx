import { NavLink } from 'react-router-dom';

const NAV_STUDENT = [
  ['/', '🏠', 'Home'],
  ['/dashboard', '📊', 'Dashboard'],
  ['/assessment', '📝', 'Skill Assessment'],
  ['/gap', '🎯', 'Skill Gap Analysis'],
  ['/jobs', '💼', 'Internships & Jobs'],
  ['/track', '📌', 'Application Tracking'],
  ['/portfolio', '🗂️', 'Digital Portfolio'],
];

const NAV_OTHER = {
  industry: [['/industry', '🏢', 'Industry Dashboard']],
  faculty: [['/faculty', '🧑‍🏫', 'Faculty Dashboard']],
  institution: [['/institution', '🏛️', 'Institution Dashboard']],
};

export default function Sidebar({ role }) {
  const nav = role === 'student' ? NAV_STUDENT : NAV_OTHER[role] || [];
  return (
    <div className="side">
      <div className="logo"><span>SB</span>SkillBridge</div>
      {nav.map(([path, icon, label]) => (
        <NavLink
          key={path}
          to={path}
          end={path === '/'}
          className={({ isActive }) => 'navitem' + (isActive ? ' active' : '')}
        >
          <span>{icon}</span>{label}
        </NavLink>
      ))}
    </div>
  );
}
